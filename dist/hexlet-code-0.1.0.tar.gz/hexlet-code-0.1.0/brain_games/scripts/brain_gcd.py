#!/usr/bin/env python
from brain_games.cli import a
from brain_games.games.cli_gcd import gcd


def main():
    print(gcd())


if __name__ == '__main__':
    main()
