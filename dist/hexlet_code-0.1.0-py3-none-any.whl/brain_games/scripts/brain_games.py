#!/usr/bin/env python
from brain_games.cli import a


def main():
    return


if __name__ == '__main__':
    main()
